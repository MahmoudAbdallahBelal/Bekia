package bekia.recycle.views.forget_password;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import bekia.recycle.R;

public class ForgetPasswordActivity extends AppCompatActivity {

    EditText forgetPasswordEdit;
    Button restorePasswordBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);


        forgetPasswordEdit = findViewById(R.id.email_forget_password_edit);
        restorePasswordBtn = findViewById(R.id.restore_password_button);

    }
}
