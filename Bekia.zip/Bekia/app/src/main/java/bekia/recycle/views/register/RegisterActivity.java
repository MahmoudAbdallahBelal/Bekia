package bekia.recycle.views.register;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import bekia.recycle.R;
import bekia.recycle.requests.register.RegisterRequest;
import bekia.recycle.requests.register.RegisterResponse;
import bekia.recycle.web.ApiClient;
import bekia.recycle.web.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    RadioButton radioUser, radioCompany;
    EditText nameEdit,userNameEdit,phoneEdit,emailEdit,passwordEdit,confirmPasswordEdit;
    Button registerBtn;

    int userCheck = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        radioUser = findViewById(R.id.radio_user);
        radioCompany = findViewById(R.id.radio_company);
        nameEdit = findViewById(R.id.name_register_edit);
        userNameEdit = findViewById(R.id.username_register_edit);
        phoneEdit = findViewById(R.id.phone_register_edit);
        emailEdit = findViewById(R.id.email_register_edit);
        passwordEdit = findViewById(R.id.password_register_edit);
        confirmPasswordEdit = findViewById(R.id.confirm_password_edit_register);
        registerBtn = findViewById(R.id.register_register_button);


        doRegister();

    }


    private  void doRegister()
    {

        radioUser.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               userCheck = 2;
            }
        });

        radioCompany.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                userCheck = 1;
            }
        });


          ApiInterface apiService =
                ApiClient.getClient().create(ApiInterface.class);

        RegisterRequest registerRequest = new RegisterRequest();
        registerRequest.setCityId(1);
        registerRequest.setEmail(emailEdit.getText().toString());
        registerRequest.setName(nameEdit.getText().toString());
        registerRequest.setPassword(passwordEdit.getText().toString());
        registerRequest.setUserType(userCheck);
        registerRequest.setPhone(phoneEdit.getText().toString());

        Call<RegisterResponse> call = apiService.registerApi("en" ,registerRequest );
        call.enqueue(new Callback<RegisterResponse>() {
            @Override
            public void onResponse(Call<RegisterResponse>call, Response<RegisterResponse> response) {
               // List<String> movies = response.body();
               // Log.d(TAG, "Number of movies received: " + movies.size());
                if(response.body().getCode().equals("200"))
                {
                    Toast.makeText(RegisterActivity.this, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<RegisterResponse>call, Throwable t) {
                Toast.makeText(RegisterActivity.this, ""+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });



    }
}
