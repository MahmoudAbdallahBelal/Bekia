package bekia.recycle.web;

import bekia.recycle.requests.register.RegisterRequest;
import bekia.recycle.requests.register.RegisterResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @POST("auth/signup")
    Call<RegisterResponse> registerApi(@Query("lang") String language , @Body RegisterRequest registerRequest);



}
