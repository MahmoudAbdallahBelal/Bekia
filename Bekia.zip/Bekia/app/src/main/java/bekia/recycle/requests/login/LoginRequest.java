package bekia.recycle.requests.login;

public class LoginRequest {
}
